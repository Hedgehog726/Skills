# Attribution and reporting method

## Accounting rules

- Count `frame.len` once per captured frame. Explain that this is captured on-wire frame length, not ISP billing data.
- For a target IP, upload means target is source; download means target is destination. Broadcast, multicast, hairpin, mirrored, tunneled, or duplicate traffic may be ambiguous.
- For a conversation, canonicalize the endpoint pair so both directions share one row, but retain directional byte counters.
- Report capture-byte coverage: `sum(classified frame.len) / capture frame.len`. Investigate material gaps.
- Distinguish packet bytes, TCP/UDP payload bytes, HTTP content length, and reassembled object size. Do not add unlike measures.

## Anomaly tests

Use several signals:

- Contribution: share of capture or target bytes.
- Burst: peak fixed-window bytes compared with median; use MAD or IQR when possible.
- Persistence: active windows / observed windows.
- Asymmetry: larger direction / smaller direction, handling zero safely.
- Transport inefficiency: retransmission bytes/packets, resets, repeated SYNs, duplicate ACKs, zero windows.
- Behavioral identity: DNS/SNI/HTTP/QUIC names, port, certificate, timing, packet sizes, and direction.

Label confidence:

- **High:** direct application evidence plus matching byte/timing behavior.
- **Medium:** multiple consistent indirect signals, but encryption/CDN/NAT prevents direct proof.
- **Low:** port/IP ownership or traffic shape alone.

## Cause checklist

| Pattern | Possible cause | Confirmation evidence |
|---|---|---|
| Large sustained download, few peers | update, streaming, bulk download | SNI/Host, content type, long streams |
| Large sustained upload | backup, sync, camera/media upload, exfiltration | device role, SNI/DNS, schedule, payload direction |
| Symmetric high rate | VPN, replication, conferencing, P2P | protocol metadata, peers, timing |
| Repeated similar bursts | scheduled sync/telemetry | periodicity, names, identical destinations |
| Many retransmissions with high frame bytes | loss/congestion inflating observed traffic | retransmission filters, RTT, duplicate ACKs |
| Many short failed sessions | retry storm, blocked service, scan | SYN/reset/ICMP ratios, repeated targets |
| One server IP, many hostnames | CDN/proxy/shared hosting | SNI/DNS/HTTP host diversity |

## Report discipline

For every major finding, provide: byte count, percentage, direction, time range/peak window, endpoint/service, protocol, evidence, confidence, alternative explanation, and a reproducible filter. Separate “Observed” from “Likely explanation.” End with actions ordered by impact and effort.


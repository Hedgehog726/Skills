# Wireshark MCP capability map

Wireshark MCP implementations expose different names. Inspect the available tools and map these capabilities:

| Capability | Common tool-name examples | Safe use on long captures |
|---|---|---|
| Capture/file metadata | capture info, file info, capinfos | Always first |
| Endpoint/conversation statistics | endpoints, conversations, summary stats | Prefer aggregated output |
| Protocol hierarchy | protocol hierarchy, protocol stats | Prefer aggregated output |
| Field extraction | extract fields, query packets | Supply a filter, selected fields, and limit |
| Packet detail | packet detail, frame detail | Only representative frame numbers |
| Stream reconstruction | follow TCP/UDP/HTTP stream | Only a selected stream; redact secrets |
| Live capture | start/stop capture, capture packets | Use rotation, duration/file-size limits, and capture filters |

Useful display-filter families:

- Target: `ip.addr == 192.0.2.10` or `ipv6.addr == 2001:db8::10`
- Direction: `ip.src == TARGET`, `ip.dst == TARGET`
- Conversation: `(ip.addr == A && ip.addr == B) && tcp.port == P`
- Time slice: `frame.time_epoch >= START && frame.time_epoch < END`
- Quality: `tcp.analysis.retransmission`, `tcp.analysis.lost_segment`, `tcp.analysis.zero_window`, `tcp.flags.reset == 1`
- Naming: `dns`, `tls.handshake.extensions_server_name`, `http.host`, `quic`

Capture filters are BPF and differ from display filters. Apply a target capture filter only when future traffic outside the target is definitely irrelevant; otherwise preserve discovery evidence.

Fallback hierarchy:

1. Use MCP aggregate/statistics tools.
2. Use `scripts/triage_capture.py` for deterministic, bounded local aggregation.
3. Use direct `tshark -r ... -Y FILTER -T fields -e ...` for a narrow evidence question.
4. Use packet listings only for a handful of frames.


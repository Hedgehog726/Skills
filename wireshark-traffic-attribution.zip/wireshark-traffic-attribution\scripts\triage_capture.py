#!/usr/bin/env python3
"""Stream PCAP fields through tshark and produce bounded traffic-attribution evidence."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import shutil
import subprocess
import sys
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

CAPTURE_SUFFIXES = {".pcap", ".pcapng", ".cap"}
FIELDS = [
    "frame.time_epoch", "frame.len", "ip.src", "ip.dst", "ipv6.src", "ipv6.dst",
    "_ws.col.Protocol", "tcp.srcport", "tcp.dstport", "udp.srcport", "udp.dstport",
    "dns.qry.name", "tls.handshake.extensions_server_name", "http.host",
]


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("capture", type=Path, help="PCAP/PCAPNG file or directory")
    p.add_argument("--out", type=Path, required=True, help="Output directory")
    p.add_argument("--target", action="append", default=[], help="Target IP; repeatable")
    p.add_argument("--window", type=int, default=3600, help="Time window in seconds")
    p.add_argument("--top", type=int, default=30, help="Rows retained in reports")
    p.add_argument("--tshark", default="tshark", help="tshark executable path")
    p.add_argument("--display-filter", default="", help="Optional Wireshark display filter")
    return p


def captures(path: Path) -> list[Path]:
    if path.is_file():
        return [path]
    if path.is_dir():
        return sorted(p for p in path.rglob("*") if p.is_file() and p.suffix.lower() in CAPTURE_SUFFIXES)
    raise FileNotFoundError(path)


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def human(n: int) -> str:
    units = ["B", "KiB", "MiB", "GiB", "TiB"]
    value = float(n)
    for unit in units:
        if value < 1024 or unit == units[-1]:
            return f"{value:.2f} {unit}"
        value /= 1024
    return f"{n} B"


def iso(epoch: float | None) -> str | None:
    return datetime.fromtimestamp(epoch, timezone.utc).isoformat() if epoch is not None else None


def main() -> int:
    a = parser().parse_args()
    if a.window <= 0 or a.top <= 0:
        raise SystemExit("--window and --top must be positive")
    executable = shutil.which(a.tshark) if not Path(a.tshark).exists() else a.tshark
    if not executable:
        raise SystemExit(f"tshark not found: {a.tshark}")
    files = captures(a.capture)
    if not files:
        raise SystemExit("no capture files found")
    a.out.mkdir(parents=True, exist_ok=True)

    endpoints = defaultdict(lambda: {"sent": 0, "received": 0, "packets_sent": 0, "packets_received": 0})
    conversations = defaultdict(lambda: {"bytes": 0, "packets": 0, "a_to_b": 0, "b_to_a": 0})
    protocols = defaultdict(lambda: {"bytes": 0, "packets": 0})
    windows = defaultdict(lambda: {"bytes": 0, "packets": 0})
    names = defaultdict(lambda: {"bytes": 0, "packets": 0, "sources": set()})
    target_dir = {t: {"upload": 0, "download": 0, "packets_upload": 0, "packets_download": 0} for t in a.target}
    manifests, errors = [], []
    total_bytes = total_packets = 0
    first = last = None

    for index, path in enumerate(files, 1):
        print(f"[{index}/{len(files)}] {path}", file=sys.stderr)
        manifest = {"path": str(path.resolve()), "size": path.stat().st_size, "sha256": sha256(path), "packets": 0, "bytes": 0}
        cmd = [str(executable), "-n", "-r", str(path), "-T", "fields", "-E", "separator=/t", "-E", "quote=n", "-E", "occurrence=f"]
        if a.display_filter:
            cmd += ["-Y", a.display_filter]
        for field in FIELDS:
            cmd += ["-e", field]
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, encoding="utf-8", errors="replace")
        assert proc.stdout is not None
        for raw in proc.stdout:
            cols = raw.rstrip("\r\n").split("\t")
            cols += [""] * (len(FIELDS) - len(cols))
            row = dict(zip(FIELDS, cols))
            try:
                ts, length = float(row["frame.time_epoch"]), int(row["frame.len"])
            except ValueError:
                continue
            src = row["ip.src"] or row["ipv6.src"] or "non-ip"
            dst = row["ip.dst"] or row["ipv6.dst"] or "non-ip"
            proto = (row["_ws.col.Protocol"] or "UNKNOWN").upper()
            sport = row["tcp.srcport"] or row["udp.srcport"] or ""
            dport = row["tcp.dstport"] or row["udp.dstport"] or ""
            transport = "TCP" if row["tcp.srcport"] else ("UDP" if row["udp.srcport"] else proto)
            ep1, ep2 = (src, sport), (dst, dport)
            a_ep, b_ep = sorted((ep1, ep2))
            key = (a_ep[0], a_ep[1], b_ep[0], b_ep[1], transport)
            c = conversations[key]
            c["bytes"] += length; c["packets"] += 1
            c["a_to_b" if ep1 == a_ep else "b_to_a"] += length
            endpoints[src]["sent"] += length; endpoints[src]["packets_sent"] += 1
            endpoints[dst]["received"] += length; endpoints[dst]["packets_received"] += 1
            protocols[proto]["bytes"] += length; protocols[proto]["packets"] += 1
            w = int(ts // a.window) * a.window
            windows[w]["bytes"] += length; windows[w]["packets"] += 1
            for value, source in ((row["dns.qry.name"], "dns"), (row["tls.handshake.extensions_server_name"], "tls_sni"), (row["http.host"], "http_host")):
                if value:
                    names[value]["bytes"] += length; names[value]["packets"] += 1; names[value]["sources"].add(source)
            for target in a.target:
                if src == target: target_dir[target]["upload"] += length; target_dir[target]["packets_upload"] += 1
                if dst == target: target_dir[target]["download"] += length; target_dir[target]["packets_download"] += 1
            total_bytes += length; total_packets += 1
            manifest["bytes"] += length; manifest["packets"] += 1
            first = ts if first is None else min(first, ts); last = ts if last is None else max(last, ts)
        stderr = proc.stderr.read() if proc.stderr else ""
        code = proc.wait()
        if code:
            errors.append({"file": str(path), "exit_code": code, "stderr": stderr[-4000:]})
        manifests.append(manifest)

    endpoint_rows = [{"ip": ip, **v, "total": v["sent"] + v["received"], "share": (v["sent"] + v["received"]) / total_bytes if total_bytes else 0} for ip, v in endpoints.items()]
    conv_rows = [{"endpoint_a": k[0], "port_a": k[1], "endpoint_b": k[2], "port_b": k[3], "transport": k[4], **v, "share": v["bytes"] / total_bytes if total_bytes else 0} for k, v in conversations.items()]
    protocol_rows = [{"protocol": k, **v, "share": v["bytes"] / total_bytes if total_bytes else 0} for k, v in protocols.items()]
    window_rows = [{"start_epoch": k, "start_utc": iso(k), **v, "bits_per_second": v["bytes"] * 8 / a.window} for k, v in windows.items()]
    name_rows = [{"name": k, "sources": sorted(v["sources"]), "bytes_on_name_frames": v["bytes"], "packets": v["packets"]} for k, v in names.items()]
    endpoint_rows.sort(key=lambda x: x["total"], reverse=True); conv_rows.sort(key=lambda x: x["bytes"], reverse=True)
    protocol_rows.sort(key=lambda x: x["bytes"], reverse=True); window_rows.sort(key=lambda x: x["start_epoch"])
    name_rows.sort(key=lambda x: x["packets"], reverse=True)

    summary = {"scope": {"files": manifests, "display_filter": a.display_filter or None, "targets": a.target, "window_seconds": a.window},
               "totals": {"packets": total_packets, "bytes": total_bytes, "first_utc": iso(first), "last_utc": iso(last), "duration_seconds": (last - first) if first is not None and last is not None else 0},
               "target_directions": target_dir, "top_endpoints": endpoint_rows[:a.top], "top_conversations": conv_rows[:a.top],
               "protocols": protocol_rows[:a.top], "windows": window_rows, "observed_names": name_rows[:a.top], "errors": errors,
               "caveats": ["Endpoint totals count each IP frame at both source and destination; shares are therefore ranking aids, not additive capture shares.", "Name-frame bytes are bytes of DNS/TLS/HTTP metadata frames, not total application traffic for that name."]}
    (a.out / "summary.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")

    for filename, rows in (("endpoints.csv", endpoint_rows), ("conversations.csv", conv_rows), ("protocols.csv", protocol_rows), ("windows.csv", window_rows), ("names.csv", name_rows)):
        if rows:
            with (a.out / filename).open("w", newline="", encoding="utf-8-sig") as f:
                w = csv.DictWriter(f, fieldnames=rows[0].keys()); w.writeheader(); w.writerows(rows)

    lines = ["# Capture triage", "", f"- Files: {len(files)}", f"- Packets: {total_packets:,}", f"- Captured bytes: {total_bytes:,} ({human(total_bytes)})", f"- UTC range: {iso(first)} — {iso(last)}", f"- tshark errors: {len(errors)}", "", "## Top endpoints", "", "| IP | Sent | Received | Endpoint total* |", "|---|---:|---:|---:|"]
    for r in endpoint_rows[:a.top]: lines.append(f"| {r['ip']} | {human(r['sent'])} | {human(r['received'])} | {human(r['total'])} |")
    lines += ["", "\\* Endpoint totals are non-additive because each IP packet has a source and destination.", "", "## Top conversations", "", "| A | B | Transport | Bytes | Packets |", "|---|---|---|---:|---:|"]
    for r in conv_rows[:a.top]: lines.append(f"| {r['endpoint_a']}:{r['port_a']} | {r['endpoint_b']}:{r['port_b']} | {r['transport']} | {human(r['bytes'])} | {r['packets']:,} |")
    lines += ["", "## Next step", "", "Use the JSON/CSV aggregates to select top conversations, then query Wireshark MCP with narrow conversation and time-window filters. Names in `names.csv` are discovery clues, not byte attribution."]
    (a.out / "triage.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(str((a.out / "summary.json").resolve()))
    return 2 if errors else 0


if __name__ == "__main__":
    raise SystemExit(main())

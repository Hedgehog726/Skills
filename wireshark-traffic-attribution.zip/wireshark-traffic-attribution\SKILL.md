---
name: wireshark-traffic-attribution
description: Attribute abnormal or excessive bandwidth usage from Wireshark PCAP/PCAPNG captures, especially multi-file or multi-day captures. Use with a Wireshark/tshark MCP server when a user asks which IP, peer, protocol, service, domain, stream, upload, download, backup, camera, endpoint, or application consumed traffic; supports a specified target IP or automatic discovery when no IP is supplied, and produces an evidence-backed Chinese or English incident report with likely causes and confidence levels.
---

# Wireshark Traffic Attribution

Attribute bytes to endpoints and conversations before inspecting packets. Treat packet evidence as authoritative and explanations as hypotheses.

## Inputs

Obtain or infer:

- Capture path(s), time zone, and expected capture point (endpoint, gateway, SPAN/TAP, VPN).
- Optional target IP/CIDR, expected device role, and known normal bandwidth.
- Whether `frame.len` (on-wire captured size) or payload/application bytes answer the billing question. Default to `frame.len`; disclose capture loss, snap length, offload, encapsulation, and duplicate-observation limitations.

Do not block on missing target IP. Enter discovery mode. Do not block on missing context; label assumptions.

## Tool strategy

Discover the connected Wireshark MCP tools and map them by capability, not by exact name. See [references/mcp-capabilities.md](references/mcp-capabilities.md). Prefer MCP for capture metadata, statistics, filters, stream following, and selected packet details. If MCP cannot aggregate a large capture safely, use local `tshark`, `capinfos`, `mergecap`, or `editcap` through the shell. Never send an unbounded packet listing into model context.

For repeatable local triage, run:

```text
python scripts/triage_capture.py CAPTURE_OR_DIRECTORY --out OUTPUT_DIRECTORY [--target 192.0.2.10] [--window 3600] [--top 30]
```

The script streams fields from `tshark`, keeps bounded top-level aggregates, and writes JSON/CSV/Markdown evidence. Read its `summary.json` and `triage.md`, not raw TSV output.

## Workflow

1. **Inventory without packet expansion.** Record file hashes, sizes, formats, first/last timestamps, duration, interfaces, packet count, average rate, snap length, and capture gaps/errors. Process rotated files independently; do not merge multi-day captures unless a tool requires it.
2. **Establish accounting scope.** State capture point and possible double counting. With a target, classify every byte as upload, download, same-target, or ambiguous. Without a target, rank endpoints by total, sent, received, peak window, and share of all captured bytes; select the smallest set explaining at least 80% of bytes, capped at 10 endpoints.
3. **Run coarse aggregation.** Rank IP conversations, transport conversations, ports, protocol hierarchy, and fixed time windows. Preserve both bytes and packets. Compare total accounted bytes with capture totals and report the coverage ratio.
4. **Detect anomalies.** Evaluate volume share, peak-to-baseline ratio, persistence/duty cycle, new peers, unusual ports, periodicity, upload/download asymmetry, many-small-packet overhead, retransmissions, resets, zero-window events, and repeated handshakes. Use medians and MAD/IQR when enough windows exist; do not call “abnormal” solely because a flow is the largest.
5. **Enrich only top contributors.** For top conversations, extract DNS names, TLS SNI/ALPN/certificates, HTTP Host/URI/content length, QUIC metadata, application protocol, MAC/vendor clues, NAT/proxy evidence, and representative frames. Follow only relevant streams and cap output. Never claim the visible server IP is the ultimate application when CDN, proxy, VPN, NAT, or encrypted traffic obscures attribution.
6. **Explain causes with alternatives.** Distinguish observation, inference, and speculation. Map evidence to likely categories such as software update, backup/sync, media streaming, surveillance upload, file transfer, telemetry, replication, scan/attack, retry storm, retransmission, keepalive chatter, or capture duplication. Require at least two independent signals for a high-confidence cause.
7. **Validate.** Re-run byte totals with a narrow display filter for every report headline. Ensure direction sums equal conversation totals within rounding, timestamps use one time zone, and no sampled result is presented as a complete total.
8. **Report.** Follow [references/report-method.md](references/report-method.md) and copy [assets/report-template.md](assets/report-template.md). Include exact filters/tool calls or reproducible commands, limitations, confidence, and next actions.

## Long-capture guardrails

- Work breadth-first: metadata → aggregate tables → top flows → selected streams → selected frames.
- Prefer one streaming pass across each file. Re-scan only narrowed filters.
- Use hourly windows by default for captures over 24 hours, 5-minute windows for under 6 hours, and daily rollups in addition to hourly windows for captures over 7 days.
- Maintain checkpoints per file. If interrupted, retain completed evidence and resume at the next file.
- Bound every MCP result by filter, fields, time range, frame range, or limit. Stop and narrow if a result could exceed roughly 10,000 rows or the MCP response limit.
- Never load payloads, credentials, cookies, tokens, full URLs with secrets, or unrelated personal data into the report. Redact unless essential and authorized.
- If packets are missing or capture quality is poor, produce a partial report with explicit confidence rather than inventing attribution.

## Required result quality

Answer: who consumed traffic, with whom, how much, in which direction, when, using what protocol/service, why it likely happened, what evidence supports that explanation, what remains uncertain, and what action would confirm or remediate it. Quantify bytes in IEC units and rates in bits/s; also provide raw byte counts for auditable totals.

